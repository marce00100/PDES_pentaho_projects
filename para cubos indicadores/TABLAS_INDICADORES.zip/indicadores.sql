/*
Navicat PGSQL Data Transfer

Source Server         : entreparentesys
Source Server Version : 90313
Source Host           : entreparentesys.com:5432
Source Database       : base_estadistica
Source Schema         : public

Target Server Type    : PGSQL
Target Server Version : 90313
File Encoding         : 65001

Date: 2017-03-08 17:26:12
*/


-- ----------------------------
-- Table structure for indicadores
-- ----------------------------
DROP TABLE IF EXISTS "public"."indicadores";
CREATE TABLE "public"."indicadores" (
"id_indicador" int4 NOT NULL,
"tipo_indicador" varchar(32) COLLATE "default",
"nombre" varchar COLLATE "default",
"estado" bool,
"dimensiones" varchar COLLATE "default",
"fuente_informacion" varchar COLLATE "default",
"definicion" varchar COLLATE "default",
"unidad_medida" varchar COLLATE "default",
"periodicidad" varchar COLLATE "default",
"cobertura_geografica" varchar COLLATE "default",
"cobertura_poblacional" varchar COLLATE "default",
"disponibilidad" bool,
"ambito_geografico" varchar COLLATE "default",
"formula" varchar COLLATE "default",
"parametros_formula" varchar COLLATE "default",
"institucion" varchar COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Records of indicadores
-- ----------------------------

-- ----------------------------
-- Alter Sequences Owned By 
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table indicadores
-- ----------------------------
ALTER TABLE "public"."indicadores" ADD PRIMARY KEY ("id_indicador");
