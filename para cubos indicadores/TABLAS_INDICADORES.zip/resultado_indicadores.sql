/*
Navicat PGSQL Data Transfer

Source Server         : entreparentesys
Source Server Version : 90313
Source Host           : entreparentesys.com:5432
Source Database       : base_estadistica
Source Schema         : public

Target Server Type    : PGSQL
Target Server Version : 90313
File Encoding         : 65001

Date: 2017-03-08 17:26:59
*/


-- ----------------------------
-- Table structure for resultado_indicadores
-- ----------------------------
DROP TABLE IF EXISTS "public"."resultado_indicadores";
CREATE TABLE "public"."resultado_indicadores" (
"id_resultado_indicador" int4 NOT NULL,
"id_resultado" int4,
"id_indicador" int4,
"punto_medicion" varchar COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Records of resultado_indicadores
-- ----------------------------

-- ----------------------------
-- Alter Sequences Owned By 
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table resultado_indicadores
-- ----------------------------
ALTER TABLE "public"."resultado_indicadores" ADD PRIMARY KEY ("id_resultado_indicador");

-- ----------------------------
-- Foreign Key structure for table "public"."resultado_indicadores"
-- ----------------------------
ALTER TABLE "public"."resultado_indicadores" ADD FOREIGN KEY ("id_indicador") REFERENCES "public"."indicadores" ("id_indicador") ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE "public"."resultado_indicadores" ADD FOREIGN KEY ("id_resultado") REFERENCES "public"."resultados" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;
